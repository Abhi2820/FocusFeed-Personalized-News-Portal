import sqlite3
import os


DB_PATH = r'C:\Users\admin\OneDrive\Desktop\BE-Project\FocusFeed\focusfeed\instances\focusfeed.db'

def create_users_table():
    try:
     
        os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)
       
        connection = sqlite3.connect(DB_PATH)
        cursor = connection.cursor()
        
        
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT UNIQUE NOT NULL,
                password TEXT NOT NULL
            );
        ''')
        
        print("Table 'users' created successfully.")
        connection.commit()
        connection.close()
    except sqlite3.OperationalError as e:
        print(f"SQLite error: {e}")
    except Exception as e:
        print(f"Unexpected error: {e}")

if __name__ == "__main__":
    create_users_table()
