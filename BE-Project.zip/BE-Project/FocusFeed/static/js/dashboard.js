/*
document.addEventListener('DOMContentLoaded', () => {
    const settingsBtn = document.querySelector('.settings-btn');
    const settingsModal = document.querySelector('.settings-modal');
    const logoutBtn = document.querySelector('.logout-btn');
    const topicsBar = document.querySelector('.topics-bar');
    const topicsList = document.querySelectorAll('.topics-list input[type="checkbox"]');

   
    settingsBtn.addEventListener('click', () => {
        settingsModal.classList.toggle('active'); 
    });

    
    logoutBtn.addEventListener('click', () => {
        window.location.href = 'login.html';
    });

    
    topicsList.forEach(topic => {
        topic.addEventListener('change', () => {
            updateTopicsBar();
        });
    });

    function updateTopicsBar() {
        const selectedTopics = Array.from(topicsList)
            .filter(topic => topic.checked)
            .map(topic => topic.value);

        
        const dynamicButtons = Array.from(topicsBar.querySelectorAll('.topic-btn.dynamic'));
        dynamicButtons.forEach(btn => btn.remove());

        
        selectedTopics.forEach(topic => {
            const btn = document.createElement('button');
            btn.classList.add('topic-btn', 'dynamic');
            btn.textContent = topic;
            topicsBar.appendChild(btn);

            
            btn.addEventListener('click', () => {
                console.log(`Filtering news by topic: ${topic}`);
                
            });
        });
    }

    function updateTopicsBar() {
        const selectedTopics = Array.from(topicsList)
            .filter(topic => topic.checked)
            .map(topic => topic.value);
        const dynamicButtons = Array.from(topicsBar.querySelectorAll('.topic-btn.dynamic'));
        dynamicButtons.forEach(btn => btn.remove());
        selectedTopics.forEach(topic => {
            const btn = document.createElement('button');
            btn.classList.add('topic-btn', 'dynamic');
            btn.textContent = topic;
            topicsBar.appendChild(btn);
            btn.addEventListener('click', () => {
                filterArticlesByTopic(topic);
            });
        });
    }
    function filterArticlesByTopic(topic) {
        const articles = document.querySelectorAll('.article');
        articles.forEach(article => {
            const title = article.querySelector('h3').textContent.toLowerCase();
            if (title.includes(topic.toLowerCase())) {
                article.style.display = 'block';
            } else {
                article.style.display = 'none';
            }
        });
    }
// Add this function to track interactions
function trackInteraction(articleId, interactionType) {
    fetch('/track-interaction', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({
            article_id: articleId,
            type: interactionType
        })
    });
}

// Add event listeners to article elements
document.querySelectorAll('.article').forEach(article => {
    article.addEventListener('click', () => {
        trackInteraction(article.dataset.articleId, 'click');
    });
});
    allNewsBtn.addEventListener('click', () => {
        showAllArticles();
    });

    function updateTopicsBar() {
        const selectedTopics = Array.from(topicsList)
            .filter(topic => topic.checked)
            .map(topic => topic.value);

        const dynamicButtons = Array.from(topicsBar.querySelectorAll('.topic-btn.dynamic'));
        dynamicButtons.forEach(btn => btn.remove());

        selectedTopics.forEach(topic => {
            const btn = document.createElement('button');
            btn.classList.add('topic-btn', 'dynamic');
            btn.textContent = topic;
            topicsBar.appendChild(btn);

            btn.addEventListener('click', () => {
                filterArticlesByTopic(topic);
            });
        });
    }

    function filterArticlesByTopic(topic) {
        fetch('/filter-articles', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ topic: topic })
        })
        .then(response => response.json())
        .then(data => {
            const articlesContainer = document.querySelector('.articles-container');
            articlesContainer.innerHTML = '';
            
            data.articles.forEach(article => {
                const articleElement = createArticleElement(article);
                articlesContainer.appendChild(articleElement);
            });
        })
        .catch(error => console.error('Error:', error));
    }

    function createArticleElement(article) {
        const div = document.createElement('div');
        div.className = 'article';
        div.innerHTML = `
            <h3>${article.title}</h3>
            <p class="article-description">${article.description}</p>
            <div class="article-meta">
                <span class="article-date">${new Date(article.publishedAt).toLocaleDateString()}</span>
                <a href="${article.url}" target="_blank" class="read-more">Read More</a>
            </div>
        `;
        return div;
    }

    function showAllArticles() {
        const articles = document.querySelectorAll('.article');
        articles.forEach(article => {
            article.style.display = 'block';
        });
    }

    // Add event listener for search functionality
    searchInput.addEventListener('input', () => {
        const query = searchInput.value.toLowerCase();
        const articles = document.querySelectorAll('.article');
        articles.forEach(article => {
            const title = article.querySelector('h3').textContent.toLowerCase();
            const description = article.querySelector('.article-description').textContent.toLowerCase();
            if (title.includes(query) || description.includes(query)) {
                article.style.display = 'block';
            } else {
                article.style.display = 'none';
            }
        });
    });

    updateTopicsBar();
});
*/
document.addEventListener('DOMContentLoaded', () => {
    const settingsBtn = document.querySelector('.settings-btn');
    const settingsModal = document.querySelector('.settings-modal');
    const logoutBtn = document.querySelector('.logout-btn');
    const topicsBar = document.querySelector('.topics-bar');
    const topicsList = document.querySelectorAll('.topics-list input[type="checkbox"]');
    const searchInput = document.querySelector('.search-box');
    const allNewsBtn = document.querySelector('.topic-btn');

    settingsBtn.addEventListener('click', () => {
        settingsModal.classList.toggle('active'); 
    });

    logoutBtn.addEventListener('click', () => {
        window.location.href = 'login.html';
    });

    topicsList.forEach(topic => {
        topic.addEventListener('change', () => {
            updateTopicsBar();
        });
    });

    function updateTopicsBar() {
        // Clear existing dynamic buttons
        const dynamicButtons = Array.from(topicsBar.querySelectorAll('.topic-btn.dynamic'));
        dynamicButtons.forEach(btn => btn.remove());

        // Get selected topics
        const selectedTopics = Array.from(topicsList)
            .filter(topic => topic.checked)
            .map(topic => topic.value);

        // Create new buttons for selected topics
        selectedTopics.forEach(topic => {
            const btn = document.createElement('button');
            btn.classList.add('topic-btn', 'dynamic');
            btn.textContent = topic;
            btn.addEventListener('click', () => {
                filterArticlesByTopic(topic);
            });
            topicsBar.appendChild(btn);
        });
    }

    function filterArticlesByTopic(topic) {
        const articles = document.querySelectorAll('.article');
        
        if (topic === 'All News') {
            articles.forEach(article => {
                article.style.display = 'block';
            });
            return;
        }

        articles.forEach(article => {
            const articleTopics = article.dataset.topics ? article.dataset.topics.split(',') : [];
            if (articleTopics.includes(topic)) {
                article.style.display = 'block';
            } else {
                article.style.display = 'none';
            }
        });
    }

    allNewsBtn.addEventListener('click', () => {
        filterArticlesByTopic('All News');
    });

    // Search functionality
    searchInput.addEventListener('input', () => {
        const query = searchInput.value.toLowerCase();
        const articles = document.querySelectorAll('.article');
        articles.forEach(article => {
            const title = article.querySelector('h3').textContent.toLowerCase();
            const description = article.querySelector('.article-description').textContent.toLowerCase();
            if (title.includes(query) || description.includes(query)) {
                article.style.display = 'block';
            } else {
                article.style.display = 'none';
            }
        });
    });

    // Initialize topics bar
    updateTopicsBar();
});








const modal = document.getElementById("summary-modal");
const summaryText = document.getElementById("summary-text");
const articleTitle = document.getElementById("article-title");
const translateBtn = document.getElementById("translate-btn");
const languageDropdown = document.getElementById("language-dropdown");

async function showSummary(articleUrl, title, articleElement) {
    const rect = articleElement.getBoundingClientRect();
    modal.style.top = `${window.scrollY + rect.top}px`; // Position modal near the article
    modal.style.display = "flex";
    summaryText.innerText = "Loading...";
    articleTitle.innerText = title;

    // Existing code to fetch and display the summary...
    try {
        const response = await fetch('/get-summary', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ url: articleUrl }),
        });

        const data = await response.json();
        summaryText.innerText = data.summary || "No summary available.";
        summaryText.setAttribute('data-original-summary', data.summary); // Store original summary


        if (data.error) {
            summaryText.innerText = data.error;
        } else {
            summaryText.innerText = data.summary || "No summary available.";
        }
    } catch (error) {
        console.error("Error fetching summary:", error);
        summaryText.innerText = "Failed to load summary.";
    }

}
// Function to close the modal
function closeModal() {
    modal.style.display = "none";
    summaryText.innerText = ""; // Clear summary text
    languageDropdown.value = ""; // Reset dropdown to default state
    languageDropdown.style.display = "none"; // Hide dropdown
}

// Event listener for translation
translateBtn.addEventListener("click", () => {
    languageDropdown.style.display = "block";
});

languageDropdown.addEventListener("change", async () => {
    const selectedLanguage = languageDropdown.value;
    const summary = summaryText.innerText;

    if (selectedLanguage && summary) {
        try {
            const response = await fetch('/translate-summary', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ summary, language: selectedLanguage }),
            });

            const data = await response.json();
            summaryText.innerText = data.translated_summary || "Translation failed.";
        } catch (error) {
            console.error("Error translating summary:", error);
            summaryText.innerText = "Error occurred while translating.";
        }
    }
});

