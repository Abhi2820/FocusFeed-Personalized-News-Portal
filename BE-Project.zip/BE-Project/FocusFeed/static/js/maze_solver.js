const canvas = document.getElementById('mazeCanvas');
const ctx = canvas.getContext('2d');
let cellSize, rows, cols;
let maze = [], player, goal;

function initMaze() {
    let size = parseInt(document.getElementById('difficulty').value);

    // Ensure it's always an odd number (required for recursive maze)
    if (size % 2 === 0) size += 1;

    rows = cols = size;
    cellSize = canvas.width / cols;
    generateMaze();
    player = { x: 0, y: 0 };
    goal = { x: cols - 1, y: rows - 1 };
    drawMaze();
}


function generateMaze() {
    maze = Array.from({ length: rows }, () => Array(cols).fill(1));

    function carve(x, y) {
        const directions = [[1, 0], [-1, 0], [0, 1], [0, -1]];
        directions.sort(() => Math.random() - 0.5); // Shuffle directions

        maze[y][x] = 0; // Mark the current cell as a path

        for (const [dx, dy] of directions) {
            const nx = x + dx * 2;
            const ny = y + dy * 2;

            if (nx >= 0 && nx < cols && ny >= 0 && ny < rows && maze[ny][nx] === 1) {
                maze[y + dy][x + dx] = 0; // Remove wall between cells
                carve(nx, ny);
            }
        }
    }

    carve(0, 0); // Start carving from the top-left corner

    // Create additional openings at the start
    createMultipleStartPaths();
}

function createMultipleStartPaths() {
    const startPaths = 3; // Number of starting paths
    for (let i = 0; i < startPaths; i++) {
        const randomIndex = Math.floor(Math.random() * (cols - 1) / 2) * 2 + 1; // Random odd index

        // Create opening on the top row
        maze[0][randomIndex] = 0;
        maze[1][randomIndex] = 0;
    }

    // Ensure at least one opening at the starting corner
    maze[0][0] = 0;
    maze[1][0] = 0;
}


function drawMaze() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    for (let y = 0; y < rows; y++) {
        for (let x = 0; x < cols; x++) {
            ctx.fillStyle = maze[y][x] ? '#222' : '#eee';
            ctx.fillRect(x * cellSize, y * cellSize, cellSize, cellSize);
        }
    }

    // Draw the goal
    ctx.fillStyle = '#00c853';
    ctx.fillRect(goal.x * cellSize, goal.y * cellSize, cellSize, cellSize);

    // Draw the player
    ctx.fillStyle = '#2196f3';
    ctx.beginPath();
    ctx.arc(
        player.x * cellSize + cellSize / 2,
        player.y * cellSize + cellSize / 2,
        cellSize / 3,
        0,
        Math.PI * 2
    );
    ctx.fill();
}

function movePlayer(dx, dy) {
    const newX = player.x + dx;
    const newY = player.y + dy;

    if (
        newX >= 0 && newX < cols &&
        newY >= 0 && newY < rows &&
        maze[newY][newX] === 0
    ) {
        player.x = newX;
        player.y = newY;
        drawMaze();

        if (player.x === goal.x && player.y === goal.y) {
            setTimeout(() => alert("🎉 You solved the maze!"), 100);
        }
    }
}

document.addEventListener('keydown', e => {
    switch (e.key) {
        case 'ArrowUp':
            e.preventDefault();
            movePlayer(0, -1);
            break;
        case 'ArrowDown':
            e.preventDefault();
            movePlayer(0, 1);
            break;
        case 'ArrowLeft':
            e.preventDefault();
            movePlayer(-1, 0);
            break;
        case 'ArrowRight':
            e.preventDefault();
            movePlayer(1, 0);
            break;
    }
});

document.addEventListener('DOMContentLoaded', initMaze);
