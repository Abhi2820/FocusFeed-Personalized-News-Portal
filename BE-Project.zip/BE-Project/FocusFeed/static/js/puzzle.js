class SlidingPuzzle {
    constructor() {
        this.size = 4;
        this.tiles = Array.from({length: 16}, (_, i) => i);
        this.moves = 0;
        this.time = 0;
        this.timer = null;
        
        this.gridElement = document.querySelector('.puzzle-grid');
        this.movesElement = document.querySelector('.moves');
        this.timerElement = document.querySelector('.timer');
        this.newGameButton = document.querySelector('.new-game-btn');
        
        this.newGameButton.addEventListener('click', () => this.startNewGame());
        this.startNewGame();
    }

    shuffle() {
        let currentIndex = this.tiles.length;
        while (currentIndex !== 0) {
            const randomIndex = Math.floor(Math.random() * currentIndex);
            currentIndex--;
            [this.tiles[currentIndex], this.tiles[randomIndex]] = 
            [this.tiles[randomIndex], this.tiles[currentIndex]];
        }
        
        // Ensure puzzle is solvable
        if (!this.isSolvable()) {
            // Swap first two tiles if puzzle is not solvable
            [this.tiles[0], this.tiles[1]] = [this.tiles[1], this.tiles[0]];
        }
    }

    isSolvable() {
        let inversions = 0;
        const emptyTileRow = Math.floor(this.tiles.indexOf(0) / this.size);
        
        for (let i = 0; i < this.tiles.length - 1; i++) {
            for (let j = i + 1; j < this.tiles.length; j++) {
                if (this.tiles[i] && this.tiles[j] && this.tiles[i] > this.tiles[j]) {
                    inversions++;
                }
            }
        }
        
        if (this.size % 2 === 0) {
            return (inversions + emptyTileRow) % 2 === 0;
        }
        return inversions % 2 === 0;
    }

    renderGrid() {
        this.gridElement.innerHTML = '';
        this.tiles.forEach((tile, index) => {
            const tileElement = document.createElement('div');
            tileElement.className = `tile${tile === 0 ? ' empty' : ''}`;
            if (tile !== 0) {
                tileElement.textContent = tile;
                if (tile === index + 1) {
                    tileElement.classList.add('correct');
                }
            }
            
            tileElement.addEventListener('click', () => this.moveTile(index));
            this.gridElement.appendChild(tileElement);
        });
    }

    moveTile(index) {
        const emptyIndex = this.tiles.indexOf(0);
        if (!this.isAdjacent(index, emptyIndex)) return;
        
        [this.tiles[index], this.tiles[emptyIndex]] = [this.tiles[emptyIndex], this.tiles[index]];
        this.moves++;
        this.movesElement.textContent = `Moves: ${this.moves}`;
        this.renderGrid();
        
        if (this.isComplete()) {
            clearInterval(this.timer);
            setTimeout(() => {
                alert(`Congratulations! You solved the puzzle in ${this.moves} moves and ${this.time} seconds!`);
            }, 300);
        }
    }

    isAdjacent(index1, index2) {
        const row1 = Math.floor(index1 / this.size);
        const col1 = index1 % this.size;
        const row2 = Math.floor(index2 / this.size);
        const col2 = index2 % this.size;
        
        return Math.abs(row1 - row2) + Math.abs(col1 - col2) === 1;
    }

    isComplete() {
        return this.tiles.every((tile, index) => 
            tile === 0 ? index === this.tiles.length - 1 : tile === index + 1
        );
    }

    startTimer() {
        clearInterval(this.timer);
        this.time = 0;
        this.timerElement.textContent = `Time: ${this.time}s`;
        this.timer = setInterval(() => {
            this.time++;
            this.timerElement.textContent = `Time: ${this.time}s`;
        }, 1000);
    }

    startNewGame() {
        this.moves = 0;
        this.movesElement.textContent = `Moves: ${this.moves}`;
        this.shuffle();
        this.renderGrid();
        this.startTimer();
    }
}

document.addEventListener('DOMContentLoaded', () => {
    new SlidingPuzzle();
});