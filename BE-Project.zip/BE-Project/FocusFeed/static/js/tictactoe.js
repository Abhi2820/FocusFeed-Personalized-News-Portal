let board, currentPlayer, gameActive, gridSize, isPlayerVsComputer;

function initGame() {
    gridSize = parseInt(document.getElementById('gridSize').value);
    board = Array.from({ length: gridSize }, () => Array(gridSize).fill(''));
    currentPlayer = 'X';
    gameActive = true;
    isPlayerVsComputer = document.getElementById('mode').value === 'computer';
    document.getElementById('gameStatus').textContent = `Player ${currentPlayer}'s turn`;
    renderBoard();
}

function renderBoard() {
    const boardElement = document.getElementById('ticTacToeBoard');
    boardElement.style.gridTemplateColumns = `repeat(${gridSize}, 1fr)`;
    boardElement.style.width = `${gridSize * 100}px`;
    boardElement.style.height = `${gridSize * 100}px`;
    boardElement.innerHTML = '';

    for (let y = 0; y < gridSize; y++) {
        for (let x = 0; x < gridSize; x++) {
            const cell = document.createElement('div');
            cell.classList.add('cell');
            cell.dataset.x = x;
            cell.dataset.y = y;
            cell.textContent = board[y][x];
            cell.addEventListener('click', handleCellClick);
            boardElement.appendChild(cell);
        }
    }
}

function handleCellClick(event) {
    if (!gameActive) return;

    const x = event.target.dataset.x;
    const y = event.target.dataset.y;

    if (board[y][x] !== '') return;

    board[y][x] = currentPlayer;
    event.target.textContent = currentPlayer;

    const winningCondition = checkWin();
    if (winningCondition) {
        highlightWinningCells(winningCondition);
        document.getElementById('gameStatus').textContent = `Player ${currentPlayer} wins!`;
        gameActive = false;
    } else if (board.flat().every(cell => cell !== '')) {
        document.getElementById('gameStatus').textContent = 'Draw!';
        gameActive = false;
    } else {
        currentPlayer = currentPlayer === 'X' ? 'O' : 'X';
        document.getElementById('gameStatus').textContent = `Player ${currentPlayer}'s turn`;

        if (isPlayerVsComputer && currentPlayer === 'O') {
            setTimeout(computerMove, 500); // Delay for a more natural feel
        }
    }
}

function computerMove() {
    if (!gameActive) return;

    let availableMoves = [];
    for (let y = 0; y < gridSize; y++) {
        for (let x = 0; x < gridSize; x++) {
            if (board[y][x] === '') {
                availableMoves.push({ x, y });
            }
        }
    }

    if (availableMoves.length > 0) {
        const move = availableMoves[Math.floor(Math.random() * availableMoves.length)];
        board[move.y][move.x] = currentPlayer;
        const cell = document.querySelector(`.cell[data-x='${move.x}'][data-y='${move.y}']`);
        cell.textContent = currentPlayer;

        if (checkWin()) {
            document.getElementById('gameStatus').textContent = `Player ${currentPlayer} wins!`;
            gameActive = false;
        } else if (board.flat().every(cell => cell !== '')) {
            document.getElementById('gameStatus').textContent = 'Draw!';
            gameActive = false;
        } else {
            currentPlayer = 'X';
            document.getElementById('gameStatus').textContent = `Player ${currentPlayer}'s turn`;
        }
    }
}

function checkWin() {
    const winConditions = [
        ...board.map((row, rowIndex) => row.map((_, colIndex) => ({ x: colIndex, y: rowIndex }))), // Rows
        ...board[0].map((_, colIndex) => board.map((_, rowIndex) => ({ x: colIndex, y: rowIndex }))), // Columns
        board.map((_, index) => ({ x: index, y: index })), // Diagonal top-left to bottom-right
        board.map((_, index) => ({ x: gridSize - 1 - index, y: index })) // Diagonal top-right to bottom-left
    ];

    for (let condition of winConditions) {
        if (condition.every(({ x, y }) => board[y][x] === currentPlayer)) {
            return condition;
        }
    }
    return null;
}
function highlightWinningCells(winningCondition) {
    winningCondition.forEach(({ x, y }) => {
        const cell = document.querySelector(`.cell[data-x='${x}'][data-y='${y}']`);
        cell.classList.add('highlight');
    });
}

document.addEventListener('DOMContentLoaded', initGame);


