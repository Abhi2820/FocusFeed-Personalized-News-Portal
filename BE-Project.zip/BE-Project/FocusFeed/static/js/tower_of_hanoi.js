let selectedTower = null;
let moveCount = 0;

function startGame() {
    const numDisks = parseInt(document.getElementById('disks').value);
    const tower1 = document.getElementById('tower1');
    const tower2 = document.getElementById('tower2');
    const tower3 = document.getElementById('tower3');
    
    [tower1, tower2, tower3].forEach(tower => tower.innerHTML = '');

    for (let i = numDisks; i >= 1; i--) {
        const disk = document.createElement('div');
        disk.className = 'disk';
        disk.style.width = `${30 + i * 20}px`;
        disk.dataset.size = i;
        tower1.appendChild(disk);
    }

    selectedTower = null;
    moveCount = 0;
    document.getElementById('moves').textContent = `Moves: 0`;
}

function selectTower(towerNum) {
    const tower = document.getElementById(`tower${towerNum}`);

    if (selectedTower === null) {
        const topDisk = tower.lastElementChild;
        if (topDisk) {
            selectedTower = tower;
            tower.classList.add('selected');
        }
    } else if (selectedTower === tower) {
        tower.classList.remove('selected');
        selectedTower = null;
    } else {
        const fromDisk = selectedTower.lastElementChild;
        const toDisk = tower.lastElementChild;

        if (!toDisk || parseInt(fromDisk.dataset.size) < parseInt(toDisk.dataset.size)) {
            tower.appendChild(fromDisk);
            moveCount++;
            document.getElementById('moves').textContent = `Moves: ${moveCount}`;
        }

        selectedTower.classList.remove('selected');
        selectedTower = null;

        // Check for win
        const numDisks = parseInt(document.getElementById('disks').value);
        const tower3 = document.getElementById('tower3');
        if (tower3.childElementCount === numDisks) {
            setTimeout(() => {
                alert(`Congratulations! You solved it in ${moveCount} moves!`);
            }, 300);
        }
    }
}
