class WordSearch {
    constructor() {
        this.words = ['FOCUS', 'MIND', 'BRAIN', 'THINK', 'LEARN', 'GROW', 'READ', 'STUDY'];
        this.grid = [];
        this.size = 10;
        this.foundWords = new Set();
        this.selectedCells = [];
        
        this.gridElement = document.querySelector('.word-grid');
        this.wordListElement = document.querySelector('.word-list');
        this.newGameButton = document.querySelector('.new-game-btn');
        
        this.newGameButton.addEventListener('click', () => this.startNewGame());
        this.initializeGame();
    }

    initializeGame() {
        this.createEmptyGrid();
        this.placeWords();
        this.fillEmptyCells();
        this.renderGrid();
        this.renderWordList();
        this.setupEventListeners();
    }

    createEmptyGrid() {
        this.grid = Array(this.size).fill().map(() => Array(this.size).fill(''));
    }

    placeWords() {
        this.words.forEach(word => {
            let placed = false;
            while (!placed) {
                const direction = Math.floor(Math.random() * 3); // 0: horizontal, 1: vertical, 2: diagonal
                const row = Math.floor(Math.random() * this.size);
                const col = Math.floor(Math.random() * this.size);
                
                if (this.canPlaceWord(word, row, col, direction)) {
                    this.placeWord(word, row, col, direction);
                    placed = true;
                }
            }
        });
    }

    canPlaceWord(word, row, col, direction) {
        const length = word.length;
        
        for (let i = 0; i < length; i++) {
            let newRow = row, newCol = col;
            
            if (direction === 0) newCol += i;
            else if (direction === 1) newRow += i;
            else {
                newRow += i;
                newCol += i;
            }
            
            if (newRow >= this.size || newCol >= this.size) return false;
            if (this.grid[newRow][newCol] !== '' && this.grid[newRow][newCol] !== word[i]) return false;
        }
        
        return true;
    }

    placeWord(word, row, col, direction) {
        for (let i = 0; i < word.length; i++) {
            if (direction === 0) this.grid[row][col + i] = word[i];
            else if (direction === 1) this.grid[row + i][col] = word[i];
            else this.grid[row + i][col + i] = word[i];
        }
    }

    fillEmptyCells() {
        const letters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
        for (let i = 0; i < this.size; i++) {
            for (let j = 0; j < this.size; j++) {
                if (this.grid[i][j] === '') {
                    this.grid[i][j] = letters[Math.floor(Math.random() * letters.length)];
                }
            }
        }
    }

    renderGrid() {
        this.gridElement.innerHTML = '';
        for (let i = 0; i < this.size; i++) {
            for (let j = 0; j < this.size; j++) {
                const cell = document.createElement('div');
                cell.className = 'grid-cell';
                cell.textContent = this.grid[i][j];
                cell.dataset.row = i;
                cell.dataset.col = j;
                this.gridElement.appendChild(cell);
            }
        }
    }

    renderWordList() {
        this.wordListElement.innerHTML = '';
        this.words.forEach(word => {
            const wordElement = document.createElement('div');
            wordElement.className = `word-item${this.foundWords.has(word) ? ' found' : ''}`;
            wordElement.textContent = word;
            this.wordListElement.appendChild(wordElement);
        });
    }

    setupEventListeners() {
        let isSelecting = false;

        this.gridElement.addEventListener('mousedown', (e) => {
            if (e.target.classList.contains('grid-cell')) {
                isSelecting = true;
                this.selectedCells = [e.target];
                e.target.classList.add('selected');
            }
        });

        this.gridElement.addEventListener('mouseover', (e) => {
            if (isSelecting && e.target.classList.contains('grid-cell')) {
                if (!this.selectedCells.includes(e.target)) {
                    this.selectedCells.push(e.target);
                    e.target.classList.add('selected');
                }
            }
        });

        document.addEventListener('mouseup', () => {
            if (isSelecting) {
                isSelecting = false;
                this.checkSelection();
                this.selectedCells.forEach(cell => cell.classList.remove('selected'));
                this.selectedCells = [];
            }
        });
    }

    checkSelection() {
        const word = this.selectedCells.map(cell => cell.textContent).join('');
        const reverseWord = word.split('').reverse().join('');
        
        if (this.words.includes(word) && !this.foundWords.has(word)) {
            this.foundWords.add(word);
            this.selectedCells.forEach(cell => cell.classList.add('found'));
            this.renderWordList();
            
            if (this.foundWords.size === this.words.length) {
                setTimeout(() => alert('Congratulations! You found all words!'), 500);
            }
        } else if (this.words.includes(reverseWord) && !this.foundWords.has(reverseWord)) {
            this.foundWords.add(reverseWord);
            this.selectedCells.forEach(cell => cell.classList.add('found'));
            this.renderWordList();
            
            if (this.foundWords.size === this.words.length) {
                setTimeout(() => alert('Congratulations! You found all words!'), 500);
            }
        }
    }

    startNewGame() {
        this.foundWords.clear();
        this.selectedCells = [];
        this.initializeGame();
    }
}

document.addEventListener('DOMContentLoaded', () => {
    new WordSearch();
});