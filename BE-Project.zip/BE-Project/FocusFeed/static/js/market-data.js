class MarketDataManager {
    constructor() {
        this.updateInterval = 30000; // 30 seconds
        this.init();
    }

    async init() {
        await this.updateMarketData();
        setInterval(() => this.updateMarketData(), this.updateInterval);
    }

    async updateMarketData() {
        try {
            const response = await fetch('/get-market-data');
            if (!response.ok) throw new Error(`HTTP error! status: ${response.status}`);
            const data = await response.json();
            
            Object.entries(data).forEach(([key, value]) => {
                const container = document.getElementById(`${key}-container`);
                const valueElement = document.getElementById(`${key}-value`);
                const changeElement = document.getElementById(`${key}-change`);
                
                if (container && valueElement && changeElement) {
                    if (value.status === 'success') {
                        container.classList.remove('error');
                        valueElement.textContent = value.value.toLocaleString();
                        changeElement.textContent = `${value.change > 0 ? '+' : ''}${value.change}%`;
                        changeElement.className = `change ${value.change >= 0 ? 'positive' : 'negative'}`;
                    } else {
                        container.classList.add('error');
                        valueElement.textContent = '--';
                        changeElement.textContent = '--';
                    }
                }
            });
        } catch (error) {
            console.error('Failed to fetch market data:', error);
            this.showError();
        }
    }

    showError() {
        document.querySelectorAll('.indicator').forEach(indicator => {
            indicator.classList.add('error');
            indicator.querySelector('.value').textContent = '--';
            indicator.querySelector('.change').textContent = '--';
        });
    }
}

// Initialize when document loads
document.addEventListener('DOMContentLoaded', () => {
    new MarketDataManager();
});