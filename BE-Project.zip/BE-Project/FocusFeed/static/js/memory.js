document.addEventListener('DOMContentLoaded', () => {
    const grid = document.querySelector('.memory-grid');
    const movesDisplay = document.querySelector('.moves');
    const timerDisplay = document.querySelector('.timer');
    const restartBtn = document.querySelector('.restart-btn');
    
    const emojis = ['🎮', '🎲', '🎯', '🎪', '🎨', '🎭', '🎪', '🎯'];
    let cards = [...emojis, ...emojis];
    let moves = 0;
    let time = 0;
    let timer;
    let flippedCards = [];
    let matchedPairs = 0;

    function shuffle(array) {
        for (let i = array.length - 1; i > 0; i--) {
            const j = Math.floor(Math.random() * (i + 1));
            [array[i], array[j]] = [array[j], array[i]];
        }
        return array;
    }

    function createCard(emoji) {
        const card = document.createElement('div');
        card.className = 'card';
        card.innerHTML = `
            <div class="card-face card-front">❓</div>
            <div class="card-face card-back">${emoji}</div>
        `;
        return card;
    }

    function startGame() {
        grid.innerHTML = '';
        moves = 0;
        time = 0;
        matchedPairs = 0;
        flippedCards = [];
        movesDisplay.textContent = `Moves: ${moves}`;
        timerDisplay.textContent = `Time: ${time}s`;
        clearInterval(timer);
        
        shuffle(cards);
        cards.forEach(emoji => {
            const card = createCard(emoji);
            grid.appendChild(card);
            
            card.addEventListener('click', () => flipCard(card));
        });

        timer = setInterval(() => {
            time++;
            timerDisplay.textContent = `Time: ${time}s`;
        }, 1000);
    }

    function flipCard(card) {
        if (flippedCards.length === 2 || card.classList.contains('flipped')) return;
        
        card.classList.add('flipped');
        flippedCards.push(card);

        if (flippedCards.length === 2) {
            moves++;
            movesDisplay.textContent = `Moves: ${moves}`;
            
            const [card1, card2] = flippedCards;
            const emoji1 = card1.querySelector('.card-back').textContent;
            const emoji2 = card2.querySelector('.card-back').textContent;

            if (emoji1 === emoji2) {
                matchedPairs++;
                flippedCards = [];
                
                if (matchedPairs === emojis.length) {
                    clearInterval(timer);
                    setTimeout(() => {
                        alert(`Congratulations! You won in ${moves} moves and ${time} seconds!`);
                    }, 500);
                }
            } else {
                setTimeout(() => {
                    card1.classList.remove('flipped');
                    card2.classList.remove('flipped');
                    flippedCards = [];
                }, 1000);
            }
        }
    }

    restartBtn.addEventListener('click', startGame);
    startGame();
});