class Sudoku {
    constructor() {
        this.grid = Array(9).fill().map(() => Array(9).fill(0));
        this.solution = Array(9).fill().map(() => Array(9).fill(0));
        this.difficulty = 'medium';
        this.selectedCell = null;
        
        this.gridElement = document.querySelector('.sudoku-grid');
        this.diffButtons = document.querySelectorAll('.diff-btn');
        this.newGameButton = document.querySelector('.new-game-btn');
        this.checkButton = document.querySelector('.check-btn');
        this.numberButtons = document.querySelectorAll('.num-btn');
        
        this.setupEventListeners();
        this.startNewGame();
    }

    setupEventListeners() {
        this.diffButtons.forEach(btn => {
            btn.addEventListener('click', () => {
                this.difficulty = btn.dataset.diff;
                this.diffButtons.forEach(b => b.classList.remove('active'));
                btn.classList.add('active');
                this.startNewGame();
            });
        });

        this.newGameButton.addEventListener('click', () => this.startNewGame());
        this.checkButton.addEventListener('click', () => this.checkSolution());

        this.numberButtons.forEach(btn => {
            btn.addEventListener('click', () => {
                if (this.selectedCell && !this.selectedCell.classList.contains('fixed')) {
                    const value = btn.classList.contains('erase') ? '' : btn.dataset.num;
                    this.selectedCell.textContent = value;
                    const row = parseInt(this.selectedCell.dataset.row);
                    const col = parseInt(this.selectedCell.dataset.col);
                    this.grid[row][col] = value ? parseInt(value) : 0;
                    this.validateCell(row, col);
                }
            });
        });
    }

    generateSudoku() {
        // Generate a valid Sudoku puzzle
        this.solveSudoku(this.solution);
        
        // Copy solution to current grid
        this.grid = this.solution.map(row => [...row]);
        
        // Remove numbers based on difficulty
        const cellsToRemove = {
            easy: 30,
            medium: 40,
            hard: 50
        }[this.difficulty];

        for (let i = 0; i < cellsToRemove; i++) {
            const row = Math.floor(Math.random() * 9);
            const col = Math.floor(Math.random() * 9);
            if (this.grid[row][col] !== 0) {
                this.grid[row][col] = 0;
            } else {
                i--;
            }
        }
    }

    solveSudoku(grid) {
        const emptyCell = this.findEmptyCell(grid);
        if (!emptyCell) return true;

        const [row, col] = emptyCell;
        for (let num = 1; num <= 9; num++) {
            if (this.isValid(grid, row, col, num)) {
                grid[row][col] = num;
                if (this.solveSudoku(grid)) return true;
                grid[row][col] = 0;
            }
        }
        return false;
    }

    findEmptyCell(grid) {
        for (let row = 0; row < 9; row++) {
            for (let col = 0; col < 9; col++) {
                if (grid[row][col] === 0) return [row, col];
            }
        }
        return null;
    }

    isValid(grid, row, col, num) {
        // Check row
        for (let x = 0; x < 9; x++) {
            if (grid[row][x] === num) return false;
        }

        // Check column
        for (let x = 0; x < 9; x++) {
            if (grid[x][col] === num) return false;
        }

        // Check 3x3 box
        const boxRow = Math.floor(row / 3) * 3;
        const boxCol = Math.floor(col / 3) * 3;
        for (let i = 0; i < 3; i++) {
            for (let j = 0; j < 3; j++) {
                if (grid[boxRow + i][boxCol + j] === num) return false;
            }
        }

        return true;
    }

    renderGrid() {
        this.gridElement.innerHTML = '';
        for (let i = 0; i < 9; i++) {
            for (let j = 0; j < 9; j++) {
                const cell = document.createElement('div');
                cell.className = 'cell';
                cell.dataset.row = i;
                cell.dataset.col = j;
                if (this.grid[i][j] !== 0) {
                    cell.textContent = this.grid[i][j];
                    cell.classList.add('fixed');
                }
                
                cell.addEventListener('click', () => {
                    if (this.selectedCell) {
                        this.selectedCell.classList.remove('selected');
                    }
                    cell.classList.add('selected');
                    this.selectedCell = cell;
                });
                
                this.gridElement.appendChild(cell);
            }
        }
    }

    validateCell(row, col) {
        const value = this.grid[row][col];
        if (value === 0) return true;

        // Create a copy of the grid without the current value
        const tempGrid = this.grid.map(r => [...r]);
        tempGrid[row][col] = 0;

        const isValid = this.isValid(tempGrid, row, col, value);
        const cell = this.gridElement.children[row * 9 + col];
        cell.classList.toggle('error', !isValid);
        return isValid;
    }

    checkSolution() {
        let isComplete = true;
        let isCorrect = true;

        for (let i = 0; i < 9; i++) {
            for (let j = 0; j < 9; j++) {
                if (this.grid[i][j] === 0) {
                    isComplete = false;
                } else if (this.grid[i][j] !== this.solution[i][j]) {
                    isCorrect = false;
                }
            }
        }

        if (!isComplete) {
            alert('Puzzle is not complete!');
        } else if (!isCorrect) {
            alert('Solution is incorrect. Keep trying!');
        } else {
            alert('Congratulations! You solved the puzzle!');
        }
    }

    startNewGame() {
        this.generateSudoku();
        this.renderGrid();
    }
}

document.addEventListener('DOMContentLoaded', () => {
    new Sudoku();
});