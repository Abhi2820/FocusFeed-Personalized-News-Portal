-- Existing user_interactions table (already has interaction_type)
CREATE TABLE IF NOT EXISTS user_interactions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER,
    article_id TEXT,
    interaction_type TEXT,
    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id)
);

-- New articles table for article metadata
CREATE TABLE IF NOT EXISTS articles (
    id TEXT PRIMARY KEY,
    title TEXT NOT NULL,
    category TEXT,
    publish_date DATE NOT NULL,
    url TEXT,
    summary TEXT
);

-- New article_topics table for topic mapping
CREATE TABLE IF NOT EXISTS article_topics (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    article_id TEXT,
    topic TEXT NOT NULL,
    FOREIGN KEY (article_id) REFERENCES articles(id)
);

-- Create indices for better query performance
CREATE INDEX IF NOT EXISTS idx_user_interactions_user_id ON user_interactions(user_id);
CREATE INDEX IF NOT EXISTS idx_user_interactions_article_id ON user_interactions(article_id);
CREATE INDEX IF NOT EXISTS idx_article_topics_article_id ON article_topics(article_id);
CREATE INDEX IF NOT EXISTS idx_articles_publish_date ON articles(publish_date);