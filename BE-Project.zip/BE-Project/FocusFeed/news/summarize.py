'''

import openai
import requests
from bs4 import BeautifulSoup

# Set your OpenAI API key
openai.api_key = "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"

def fetch_article_content(url):
    """
    Fetch the main content of an article from the given URL.
    """
    try:
        response = requests.get(url)
        
        response.raise_for_status()

        # Parse the HTML content
        soup = BeautifulSoup(response.text, "html.parser")

        # Extract the main content (this may vary depending on the site structure)
        paragraphs = soup.find_all("p")
        article_text = " ".join(p.get_text() for p in paragraphs)

        return article_text if article_text else "Could not extract content."
    except Exception as e:
        return f"Error fetching article: {e}"

def summarize_article_with_openai(article_text):
    """
    Generate a summary of the given article text using OpenAI's API.
    """
    try:
        prompt = f"Summarize this article:\n\n{article_text}\n\nSummary:"
        response = openai.Completion.create(
            engine="text-davinci-003",
            prompt=prompt,
            max_tokens=150,  # Adjust based on desired summary length
            temperature=0.5
        )
        return response.choices[0].text.strip()
    except Exception as e:
        return f"Error generating summary: {e}"

# Main function
def main():
    # URL of the article to summarize
    article_url = input("Enter the article URL: ")

    # Fetch the article content
    article_content = fetch_article_content(article_url)
    if article_content.startswith("Error"):
        print(article_content)
        return

    print("\nFetched Article Content:\n", article_content[:500], "...")  # Preview first 500 chars

    # Generate the summary
    summary = summarize_article_with_openai(article_content)
    print("\nGenerated Summary:\n", summary)

if __name__ == "__main__":
    main()

import requests

def fetch_and_summarize_article(url):
    """
    Fetch and summarize the article using Gemini's API.
    """
    try:
        # Replace with the actual Gemini API endpoint and payload structure
        api_url = "https://gemini-api.google.com"
        headers = {"Authorization": "AIzaSyDOHr88OqT3Ls1k60UFiHcdwn_qYkDihNM"}
        data = {"url": url, "length": "short"}  # Customize parameters as needed

        response = requests.post(api_url, headers=headers, json=data)
        response.raise_for_status()

        summary = response.json().get("summary", "No summary available.")
        return summary
    except Exception as e:
        return f"Error: {e}"

# Example test
# article_url = "https://your-article-url.com"
# print(fetch_and_summarize_article(article_url))
'''