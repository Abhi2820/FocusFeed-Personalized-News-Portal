from flask import Flask, render_template, request, redirect, url_for, session, jsonify
import yfinance as yf
from datetime import datetime
import sqlite3
from newspaper import Article
from deep_translator import GoogleTranslator
from news_fetcher import fetch_articles, detect_topics  # Add detect_topics to the import
import logging
import requests
from bs4 import BeautifulSoup
import numpy as np
from neural_collaborative import NCFModel

# Initialize Flask app only once
app = Flask(__name__)
app.secret_key = 'your_secret_key'

# Configure logging
logging.basicConfig(level=logging.DEBUG)

# Error handlers
@app.errorhandler(404)
def not_found_error(error):
    return render_template('404.html'), 404

@app.errorhandler(500)
def internal_error(error):
    return render_template('500.html'), 500

@app.route('/track-interaction', methods=['POST'])
def track_interaction():
    if 'user_id' not in session:
        return jsonify({'error': 'Not authenticated'}), 401
        
    data = request.get_json()
    article_id = data.get('article_id')
    interaction_type = data.get('type')
    
    if not article_id or not interaction_type:
        return jsonify({'error': 'Missing parameters'}), 400
        
    try:
        ncf_model = NCFModel()
        ncf_model.record_interaction(session['user_id'], article_id, interaction_type)
        return jsonify({'success': True})
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# Add this to the dashboard route to get personalized recommendations
@app.route('/dashboard')
def dashboard():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    
    conn = sqlite3.connect('focusfeed.db')
    cursor = conn.cursor()
    cursor.execute("SELECT username FROM users WHERE id = ?", (session['user_id'],))
    user = cursor.fetchone()
    conn.close()
    
    if user:
        articles = fetch_articles()
        for article in articles:
            article['topics'] = detect_topics(article['title'], article['description'])
        
        # Get personalized recommendations
        try:
            ncf_model = NCFModel()
            recommended_ids = ncf_model.get_recommendations(session['user_id'])
            # Prioritize recommended articles
            articles.sort(key=lambda x: x['id'] in recommended_ids, reverse=True)
        except Exception as e:
            logging.error(f"Error getting recommendations: {e}")
        
        articles = articles[:100]
        return render_template('dashboard.html', username=user[0], articles=articles)
    else:
        return redirect(url_for('login'))

@app.route('/filter-articles', methods=['POST'])
def filter_articles():
    data = request.get_json()
    topic = data.get('topic')
    
    if not topic:
        return jsonify({'error': 'No topic provided'}), 400
        
    articles = fetch_articles()
    filtered_articles = []
    
    for article in articles:
        article_topics = detect_topics(article['title'], article['description'])
        if topic in article_topics:
            filtered_articles.append(article)
    
    return jsonify({'articles': filtered_articles})

@app.route('/')
def landing_page():
    # Fetch top 5 articles for preview
    preview_articles = fetch_articles()[:5]
    return render_template('landing.html', preview_articles=preview_articles)

# About Us page
@app.route('/about')
def about():
    return render_template('about.html')


@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        email = request.form['email']
        password = request.form['password']
        
        
        conn = sqlite3.connect('focusfeed.db')
        cursor = conn.cursor()
        cursor.execute('''CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY, username TEXT, email TEXT, password TEXT)''')
        cursor.execute("INSERT INTO users (username, email, password) VALUES (?, ?, ?)", (username, email, password))
        conn.commit()
        conn.close()
        
        
        return redirect(url_for('login'))
    
    return render_template('register.html')


@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        
        
        conn = sqlite3.connect('focusfeed.db')
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM users WHERE username = ? AND password = ?", (username, password))
        user = cursor.fetchone()
        conn.close()
        
        if user:
            session['user_id'] = user[0]  
            session['username'] = user[1]  
            return redirect(url_for('dashboard'))
        else:
            return "Invalid credentials"
    
    return render_template('login.html')



# Logout route
@app.route('/logout')
def logout():
    session.clear()  # Clear all session data
    return redirect(url_for('login'))
    

'''
from newspaper import Article

@app.route('/get-summary', methods=['POST'])
def get_summary():
    """
    Summarize an article using `newspaper3k`.
    Expects the article URL to be sent in the POST request.
    """
    try:
        # Get the article URL from the POST request
        data = request.get_json()
        article_url = data.get('url')

        if not article_url:
            return jsonify({"error": "No article URL provided."}), 400

        # Use newspaper3k to fetch and summarize the article
        article = Article(article_url)
        article.download()
        article.parse()
        article.nlp()  # Perform NLP to extract the summary

        # Return the summary
        return jsonify({"summary": article.summary})
    except Exception as e:
        return jsonify({"error": f"Failed to summarize article. Error: {e}"}), 500
'''
from newspaper import Article
'''
@app.route('/get-summary', methods=['POST'])
def get_summary():
    """
    Summarize an article using `newspaper3k`.
    Expects the article URL to be sent in the POST request.
    """
    def summarize_and_truncate(full_text, word_count=400):
        """
        Summarizes and truncates the full text to the specified number of words (default is 400).

        Args:
            full_text (str): The full text of the article.
            word_count (int): The number of words the summary should be truncated to (default: 400).

        Returns:
            str: The truncated summary.
        """
        # Split the full text into words
        words = full_text.split()

        # Truncate to the specified number of words
        truncated = ' '.join(words[:word_count])
        return truncated

    try:
        # Get the article URL from the POST request
        data = request.get_json()
        article_url = data.get('url')

        if not article_url:
            return jsonify({"error": "No article URL provided."}), 400

        # Use newspaper3k to fetch and parse the article
        article = Article(article_url)
        article.download()
        article.parse()

        # Summarize and truncate the full text
        full_text = article.text
        truncated_summary = summarize_and_truncate(full_text, word_count=400)

        # Return the summary
        return jsonify({"summary": truncated_summary})

    except Exception as e:
        return jsonify({"error": f"Failed to summarize article. Error: {e}"}), 500

'''
 # Assuming you're using googletrans for translation



@app.route('/get-summary', methods=['POST'])
def get_summary():
    """
    Summarize an article using `newspaper3k`.
    Expects the article URL to be sent in the POST request.
    """
    def summarize_and_truncate(full_text, word_count=400):
        words = full_text.split()
        truncated = ' '.join(words[:word_count])
        return truncated

    try:
        data = request.get_json()
        article_url = data.get('url')

        if not article_url:
            return jsonify({"error": "No article URL provided."}), 400

        article = Article(article_url)
        article.download()
        article.parse()

        full_text = article.text
        truncated_summary = summarize_and_truncate(full_text, word_count=400)

        return jsonify({"summary": truncated_summary})

    except Exception as e:
        return jsonify({"error": f"Failed to summarize article. Error: {e}"}), 500


from deep_translator import GoogleTranslator


@app.route('/translate-summary', methods=['POST'])
def translate_summary():
    """
    Translate a summary into the specified language.
    Expects the summary text and target language to be sent in the POST request.
    """
    try:
        # Get JSON data from the request
        data = request.get_json()
        summary = data.get('summary')
        target_language = data.get('language')

        if not summary or not target_language:
            return jsonify({"error": "Missing summary or target language."}), 400

        # Translate using GoogleTranslator from deep-translator
        translated = GoogleTranslator(source='en', target=target_language).translate(summary)

        # Return the translated summary
        return jsonify({"translated_summary": translated})

    except Exception as e:
        return jsonify({"error": f"Failed to translate summary. Error: {e}"}), 500


@app.route('/get-market-data')
def get_market_data():
    try:
        symbols = {
            'nifty': '^NSEI',
            'banknifty': '^NSEBANK',
            'sensex': '^BSESN',
            'bitcoin': 'BTC-USD',
            'gold': 'GLD',
            'silver': 'SLV'
        }
        
        data = {}
        for key, symbol in symbols.items():
            try:
                ticker = yf.Ticker(symbol)
                current_data = ticker.history(period='1d')
                
                if current_data.empty:
                    raise ValueError(f"No market data available for {symbol}")
                
                last_price = current_data['Close'].iloc[-1]
                prev_day = ticker.history(period='2d')
                if len(prev_day) > 1:
                    prev_close = prev_day['Close'].iloc[-2]
                    percent_change = ((last_price - prev_close) / prev_close) * 100
                else:
                    percent_change = 0
                
                data[key] = {
                    'value': round(last_price, 2),
                    'change': round(percent_change, 2),
                    'status': 'success',
                    'timestamp': datetime.now().isoformat()
                }
            except Exception as e:
                print(f"Error fetching {key}: {str(e)}")
                data[key] = {
                    'status': 'error',
                    'message': f"Unable to fetch {key.upper()} data",
                    'error': str(e)
                }
        
        return jsonify(data)
    except Exception as e:
        print(f"Market data service error: {str(e)}")
        return jsonify({
            'status': 'error',
            'message': 'Market data service unavailable',
            'error': str(e)
        }), 503


# Try accessing the endpoint in your browser:
# Open: http://localhost:5000/get-market-data

# If you're still getting errors, check your app.py to ensure the market data route is properly defined:
# Move all route definitions before the if __name__ == '__main__': block
@app.route('/games')
def games():
    return render_template('games.html')  # Remove login requirement for games page

@app.route('/games/memory')
def memory_game():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    return render_template('games/memory.html')

@app.route('/games/word-search')
def word_search():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    return render_template('games/word_search.html')

@app.route('/games/sudoku')
def sudoku():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    return render_template('games/sudoku.html')

@app.route('/games/puzzle')
def puzzle():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    return render_template('games/puzzle.html')

@app.route('/games/tower-of-hanoi')
def tower_of_hanoi():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    return render_template('games/tower_of_hanoi.html')

@app.route('/games/maze-solver')
def maze_solver():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    return render_template('games/maze_solver.html')

@app.route('/games/tictactoe')
def tic_tac_toe():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    return render_template('games/tictactoe.html')


# Move this to the end of the file
if __name__ == '__main__':
    app.run(debug=True)




