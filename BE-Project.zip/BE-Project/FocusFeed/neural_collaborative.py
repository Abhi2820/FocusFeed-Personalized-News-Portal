import torch
import torch.nn as nn
import torch.optim as optim
import numpy as np
import sqlite3
from collections import defaultdict

class NCF(nn.Module):
    def __init__(self, num_users, num_items, embedding_size=50):
        super(NCF, self).__init__()
        self.user_embedding = nn.Embedding(num_users, embedding_size)
        self.item_embedding = nn.Embedding(num_items, embedding_size)
        
        self.fc_layers = nn.Sequential(
            nn.Linear(embedding_size * 2, 32),
            nn.ReLU(),
            nn.Linear(32, 16),
            nn.ReLU(),
            nn.Linear(16, 1),
            nn.Sigmoid()
        )
        
    def forward(self, user_input, item_input):
        user_embedded = self.user_embedding(user_input)
        item_embedded = self.item_embedding(item_input)
        
        vector = torch.cat([user_embedded, item_embedded], dim=-1)
        prediction = self.fc_layers(vector)
        return prediction

class NCFModel:
    def __init__(self, embedding_size=50):
        self.model = None
        self.embedding_size = embedding_size
        self.user_mapping = {}
        self.item_mapping = {}
        self.category_mapping = {}
        self.load_mappings()
        
    def get_user_preferences(self, user_id):
        conn = sqlite3.connect('focusfeed.db')
        cursor = conn.cursor()
        
        # Get user's topic preferences from interactions
        cursor.execute("""
            SELECT t.topic, COUNT(*) as topic_count
            FROM user_interactions ui
            JOIN articles a ON ui.article_id = a.id
            JOIN article_topics t ON a.id = t.article_id
            WHERE ui.user_id = ?
            GROUP BY t.topic
            ORDER BY topic_count DESC
        """, (user_id,))
        
        preferences = cursor.fetchall()
        conn.close()
        return dict(preferences)
    
    def get_recommendations(self, user_id, top_k=50):
        if user_id not in self.user_mapping:
            return []
        
        # Get base predictions
        self.model.eval()
        user_idx = self.user_mapping[user_id]
        user_tensor = torch.LongTensor([user_idx] * len(self.item_mapping))
        item_tensor = torch.LongTensor(list(range(len(self.item_mapping))))
        
        with torch.no_grad():
            base_predictions = self.model(user_tensor, item_tensor)
        
        # Get user preferences
        user_prefs = self.get_user_preferences(user_id)
        
        # Apply diversity and contextual boosting
        conn = sqlite3.connect('focusfeed.db')
        cursor = conn.cursor()
        
        recommendations = []
        seen_categories = set()
        prediction_scores = []
        
        # Get article metadata for contextual boosting
        for idx, score in enumerate(base_predictions):
            article_id = list(self.item_mapping.keys())[idx]
            
            cursor.execute("""
                SELECT a.category, a.publish_date, GROUP_CONCAT(t.topic) as topics
                FROM articles a
                LEFT JOIN article_topics t ON a.id = t.article_id
                WHERE a.id = ?
                GROUP BY a.id
            """, (article_id,))
            
            result = cursor.fetchone()
            if not result:
                continue
                
            category, publish_date, topics = result
            topics = topics.split(',') if topics else []
            
            # Time decay factor (newer articles get boosted)
            days_old = (datetime.now() - datetime.strptime(publish_date, '%Y-%m-%d')).days
            time_boost = 1.0 / (1 + 0.1 * days_old)  # Adjust 0.1 to control decay rate
            
            # Topic preference boost
            topic_boost = sum(user_prefs.get(topic, 0) for topic in topics) / len(topics) if topics else 0
            
            # Diversity penalty (if we've seen too many articles from this category)
            diversity_penalty = 0.8 if category in seen_categories else 1.0
            
            # Combine all factors
            final_score = float(score) * time_boost * (1 + 0.2 * topic_boost) * diversity_penalty
            
            prediction_scores.append((article_id, final_score))
            seen_categories.add(category)
        
        conn.close()
        
        # Sort by final scores and return top-k
        prediction_scores.sort(key=lambda x: x[1], reverse=True)
        return [article_id for article_id, _ in prediction_scores[:top_k]]

    def record_interaction(self, user_id, article_id, interaction_type):
        conn = sqlite3.connect('focusfeed.db')
        cursor = conn.cursor()
        
        # Record the interaction
        cursor.execute("""
            INSERT INTO user_interactions (user_id, article_id, interaction_type, timestamp)
            VALUES (?, ?, ?, datetime('now'))
        """, (user_id, article_id, interaction_type))
        
        conn.commit()
        conn.close()
        
        # Trigger incremental model update
        self.incremental_update(user_id, article_id, interaction_type)
    
    def incremental_update(self, user_id, article_id, interaction_type):
        # Convert IDs to indices
        user_idx = self.user_mapping[user_id]
        item_idx = self.item_mapping[article_id]
        
        # Create tensors for single interaction
        user_tensor = torch.LongTensor([user_idx])
        item_tensor = torch.LongTensor([item_idx])
        
        # Weight based on interaction type
        interaction_weights = {
            'view': 1.0,
            'click': 2.0,
            'share': 3.0,
            'bookmark': 4.0
        }
        rating = torch.FloatTensor([interaction_weights.get(interaction_type, 1.0)])
        
        # Perform single optimization step
        self.model.train()
        optimizer = optim.Adam(self.model.parameters(), lr=0.001)
        criterion = nn.MSELoss()
        
        optimizer.zero_grad()
        prediction = self.model(user_tensor, item_tensor)
        loss = criterion(prediction.squeeze(), rating)
        loss.backward()
        optimizer.step()
    
    def train(self):
        conn = sqlite3.connect('focusfeed.db')
        cursor = conn.cursor()
        
        # Get interaction data with weights and recency
        cursor.execute("""
            SELECT user_id, article_id,
                   SUM(CASE
                       WHEN interaction_type = 'click' THEN 1
                       WHEN interaction_type = 'share' THEN 2
                       WHEN interaction_type = 'bookmark' THEN 3
                       ELSE 0
                   END) * (1.0 / (1 + (julianday('now') - julianday(timestamp)))) as weighted_strength
            FROM user_interactions
            GROUP BY user_id, article_id
        """)
        interactions = cursor.fetchall()
        
        # Prepare training data with normalization
        users = torch.LongTensor([self.user_mapping[i[0]] for i in interactions])
        items = torch.LongTensor([self.item_mapping[i[1]] for i in interactions])
        ratings = torch.FloatTensor([i[2] for i in interactions])
        
        # Normalize ratings
        ratings = (ratings - ratings.mean()) / ratings.std()
        
        optimizer = optim.Adam(self.model.parameters(), lr=0.001)
        scheduler = optim.lr_scheduler.ReduceLROnPlateau(optimizer, 'min', patience=5)
        criterion = nn.MSELoss()
        
        best_loss = float('inf')
        patience = 10
        patience_counter = 0
        
        # Training loop with early stopping
        self.model.train()
        for epoch in range(500):  # Increased epochs
            optimizer.zero_grad()
            prediction = self.model(users, items)
            loss = criterion(prediction.squeeze(), ratings)
            loss.backward()
            optimizer.step()
            
            scheduler.step(loss)
            
            # Early stopping
            if loss < best_loss:
                best_loss = loss
                patience_counter = 0
            else:
                patience_counter += 1
                if patience_counter >= patience:
                    break
        
        conn.close()
    
    def load_mappings(self):
        conn = sqlite3.connect('focusfeed.db')
        cursor = conn.cursor()
        
        # Get unique users and items
        cursor.execute("SELECT DISTINCT user_id FROM user_interactions")
        users = cursor.fetchall()
        cursor.execute("SELECT DISTINCT article_id FROM user_interactions")
        items = cursor.fetchall()
        
        self.user_mapping = {user[0]: idx for idx, user in enumerate(users)}
        self.item_mapping = {item[0]: idx for idx, item in enumerate(items)}
        
        if not self.model:
            self.model = NCF(len(users), len(items), self.embedding_size)
        
        conn.close()