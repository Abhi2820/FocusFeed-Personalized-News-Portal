'''
from newspaper import Article
import nltk
nltk.download('punkt')
nltk.download('punkt_tab')


def summarize_article(url):
    try:
        # Initialize and download the article
        article = Article(url)
        article.download()
        article.parse()
        article.nlp()  # Perform NLP tasks like keyword extraction and summarization
        
        # Return the summary
        return article.summary
    except Exception as e:
        return f"Error summarizing article: {str(e)}"

if __name__ == "__main__":
    # Input the URL
    url = input("Enter the URL of the article: ").strip()
    if url:
        summary = summarize_article(url)
        print("\nSummary of the article:\n")
        print(summary)
    else:
        print("Please provide a valid URL.")

'''
from deep_translator import GoogleTranslator

# Example usage
translator = GoogleTranslator(source='en', target='fr')
result = translator.translate("Hello, how are you?")
print(result)  # This prints the translated text

