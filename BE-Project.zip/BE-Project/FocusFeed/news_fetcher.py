'''
import requests

def fetch_articles():
    url = 'https://newsapi.org/v2/everything?q=cricket+india+celebrity&apiKey=89d89754e8364a07bb50def967a1dbf6'
    params = {
        'pageSize': 12,  # Fetch only 10 articles
        'page': 1
    }

    response = requests.get(url, params=params)

    if response.status_code == 200:
        data = response.json()
        articles = data['articles'][:12]  # Limit to 10 articles, if more are returned
        print(f"API Response: {len(articles)} articles fetched.")  # Debugging
        return articles
    else:
        print(f"Error fetching articles: {response.status_code}")
        return []
'''
import requests

def fetch_articles():
    url = 'https://newsapi.org/v2/everything'
    query = ('(India OR Indian) AND (politics OR business OR technology OR sports OR entertainment OR bollywood)')
    
    params = {
        'q': query,
        'apiKey': '456a5a23cce44b059fd67e1bb5d0bc75',
        'pageSize': 100,
        'language': 'en',
        'sortBy': 'publishedAt',
        'domains': 'indianexpress.com,ndtv.com,timesofindia.indiatimes.com,hindustantimes.com,news18.com'
    }
    
    try:
        response = requests.get(url, params=params)
        
        if response.status_code == 200:
            data = response.json()
            articles = data.get('articles', [])
            
            # Debug print
            print(f"API Response: {len(articles)} articles fetched.")
            
            # Basic validation of articles
            valid_articles = [
                article for article in articles 
                if article.get('title') and article.get('description') and article.get('url')
            ]
            
            return valid_articles
        else:
            print(f"Error fetching articles: {response.status_code}")
            print(f"Response: {response.text}")
            return []

    except Exception as e:
        print(f"Exception occurred while fetching articles: {e}")
        return []

def detect_topics(title, description):
    """Detect relevant topics for an article based on its content"""
    topics = []
    content = (title + ' ' + description).lower()
    
    topic_keywords = {
        'Technology': ['tech', 'technology', 'software', 'hardware', 'digital'],
        'Politics': ['politics', 'government', 'election', 'policy', 'minister'],
        'Business': ['business', 'economy', 'market', 'company', 'industry'],
        'Sports': ['sports', 'game', 'player', 'tournament', 'match', 'cricket', 'ipl', 'football', 'tennis',
                  'basketball', 'team', 'sport', 'athlete', 'championship', 'league', 'racing', 'olympic',
                  'fifa', 'nba', 'wicket', 'batsman', 'bowler'],
        'Entertainment': ['entertainment', 'movie', 'music', 'celebrity', 'film', 'bollywood', 'hollywood', 'marvel'],
        'Health': ['health', 'medical', 'disease', 'treatment', 'wellness'],
        'Science': ['science', 'research', 'study', 'discovery'],
        'Education': ['education', 'school', 'university', 'student', 'learning'],
        'Environment': ['environment', 'climate', 'sustainability', 'green'],
        'Cryptocurrency': ['crypto', 'bitcoin', 'blockchain', 'cryptocurrency'],
        'AI': ['ai', 'artificial intelligence', 'machine learning', 'neural'],
        'Gaming': ['game', 'gaming', 'esports', 'playstation', 'xbox'],
        'Startups': ['startup', 'entrepreneur', 'venture', 'funding'],
        'International': ['global', 'world', 'international', 'foreign'],
        'Lifestyle': ['lifestyle', 'fashion', 'food', 'travel', 'culture']
    }
    
    for topic, keywords in topic_keywords.items():
        if any(keyword in content for keyword in keywords):
            topics.append(topic)
    
    return topics